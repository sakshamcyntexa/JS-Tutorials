import { LightningElement, track, api,wire } from 'lwc';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import readCSV from '@salesforce/apex/LWCExampleController.readCSVFile';
import {updateRecord} from 'lightning/uiRecordApi'
import {refreshApex} from '@salesforce/apex'

import fetchAccount from '@salesforce/apex/LWCExampleController.getAccountList';

const columns = [
    { label: 'Product Name', fieldName: 'Name' , editable:true}, 
    { label: 'Product Class', fieldName: 'Product_Picklist__c', editable:true },
    { label: 'Product Code', fieldName: 'Product_Code__c', editable:true}, 
    { label: 'Product Description', fieldName: 'Product_Description__c', editable:true}, 
    { label: 'Product Family', fieldName: 'Product_Family__c', editable:true}
];



export default class ReadCSVFileInLWC extends LightningElement {
    @api recordId;
    @track error;
    @track columns = columns;
    @track data;
    draftValues=[]
    checkSize;
    showTable=false;
    // @wire(fetchAccount)
    // accountDataFetch;
    resList=[]
    
    // accepted parameters
    get acceptedFormats() {
        return ['.csv'];
    }
    

   

    handleUploadFinished(event) {
        
        // Get the list of uploaded files
        const uploadedFiles = event.detail.files;

        // calling apex class
        readCSV({idContentDocument : uploadedFiles[0].documentId})
        .then(result => {
            window.console.log('result ===> '+result);
            this.checkSize = result.length;
            console.log(this.checkSize);
            
            this.data = result;
            fetchAccount({putSize: this.checkSize}).then(res=>{
                this.resList = res;
                console.log(this.resList)

            }).catch(err=>{
                console.log(err);
            })

            this.draftValues=[]
            refreshApex(this.data);
            // console.log(this.data);
            // console.log(this.data[0].id);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success!!',
                    message: 'Accounts are created based CSV file!!!',
                    variant: 'success',
                }),
            );
        })
        .catch(error => {
            this.error = error;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error!!',
                    message: JSON.stringify(error),
                    variant: 'error',
                }),
            );     
        })

        // showDataTable();
        this.eventOrders();

    }

    // showDataTable(){
    //     console.log('hey bro')
    //     console.log(this.accountDataFetch)
    //     this.showTable = true;

        
        

    // }
    
    eventOrders() {
        // window.console.log("this.recordId: " + this.recordId);
        fetchAccount({putSize:this.checkSize})
            .then((resWrapper) => {
                console.log("Sucessful");
                console.log("resWrapper: " + resWrapper);
                if(resWrapper){
                    window.console.log("resWrapper length: " + resWrapper.length);
                    resWrapper.forEach((res) => {
                        console.log(res)
                        console.log(res.order)
                        // window.console.log("res.order.Account.Name: " + res.order.Account.Name);
                        // window.console.log("res.order.Delivered__c: " + res.order.Delivered__c);
                        
                        // window.console.log("res.order.Status: " + res.order.Status);

                        // let lineItem = {};
                        // lineItem.accountname = res.order.Account.Name,
                        // lineItem.delivered = res.order.Delivered__c,
                        // lineItem.status = res.order.Status,
                        // window.console.log("========lineItem acc name:====== " +lineItem.accountname);
                        // this.data.push(lineItem);
                    });
                }
                // window.console.log("data.length: " + this.data.length);
            })
            .catch((error) => {
                this.error = error;
                console.log('error me ghus gaya ye')
                window.console.log("Error: " + error);
            });
    }


}